function Footer() {
    return (
        <div className="page__container">
            <div className="footer">
                <p className="footer__copyright">&copy; 2021 Mesto Russia</p>
            </div>
        </div>
    );
}

export default Footer;